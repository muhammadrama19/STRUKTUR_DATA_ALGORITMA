#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include "body.cpp"

int main()
{
    int input = 0;
    int tempDelOpt = 0;
    int tempBetween = 0;
    int tempVal = 0;
    int opsiBetween = 0;
    bool running = true;

    insert_rear(1);
    insert_front(2);
    insert_rear(3);

    printf("the original queue is:-\n");
    printqueue(fronts, rear);

    while (running)
    {
        printf("\n1.Insert\n2.Delete\n3.Lihat Front Rear\n4.Keluar\n");
        printf("Masukan pilihan anda: ");
        scanf("%d", &input);
        switch (input)
        {
        case 1:
            printf("\n1.Insert Depan.\n2.Insert Belakang\n3.Insert Between ");
            scanf("%d", &opsiBetween);
            switch (opsiBetween)
            {
            case 1:
                printf("\nMasukkan angka untuk insert di depan: ");
                scanf("%d", &input);
                insert_front(input);
                printf("Memasukkan %d di depan\n", input);
                printqueue(fronts, rear);
                break;
            case 2:
                printf("\nMasukkan angka untuk insert di belakang: ");
                scanf("%d", &input);
                insert_rear(input);
                printf("Memasukkan %d di belakang\n", input);
                printqueue(fronts, rear);
                break;
            case 3:
                printf("masukan elemen diantara: ");
                scanf("%d", &tempVal);
                printf("\nmasukan value baru: ");
                scanf("%d", &tempBetween);
                insertBetween(tempVal, tempBetween);
                printqueue(fronts, rear);
                break;
            default:
                printf("Pilihan tidak valid!\n");
                break;
            }
            break;
        case 2:
            printf("1.Delete depan\n2.Delte belakang\n");
            scanf("%d", &tempDelOpt);
            switch (tempDelOpt)
            {
            case 1:
                delete_front();
                printf("Menghapus elemen dari depan\n");
                printqueue(fronts, rear);
                break;
            case 2:
                delete_rear();
                printf("Menghapus elemen dari belakang\n");
                printqueue(fronts, rear);
                break;
            default:
                printf("Pilihan tidak valid!\n");
                break;
            }
            break;
        case 3:
            printf("Kondisi front rear terkini: \n");
            printqueue(fronts, rear);
            printf("Mendapatkan elemen depan\n");
            printf("%d\n", getfront());
            printf("Mendapatkan elemen belakang\n");
            printf("%d\n", getrear());
            break;
        case 4:
            running = false;
            break;
        default:
            printf("Pilihan tidak valid!\n");
            break;
        }
    }

    return 0;
}
