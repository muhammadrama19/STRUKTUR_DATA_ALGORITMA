#include <iostream>
#include <stdlib.h>
#include <stdio.h>

#define MAX_SIZE 10

using namespace std;

struct node {
    int data;
    struct node *prev;
    struct node *next;
};

struct node *fronts = NULL;
struct node *rear = NULL;

bool isEmpty() {
    if (fronts == NULL && rear == NULL) {
        return true;
    }
    return false;
}

bool isFull() {
    int count = 0;
    struct node *temp = fronts;
    while (temp != NULL) {
        count++;
        temp = temp->next;
    }
    if (count >= MAX_SIZE) {
        return true;
    }
    return false;
}

void insert_rear(int new_data) {
    if (isFull()) {
        printf("Queue overflow. tidak bisa insert %d.\n", new_data);
        return;
    }

    struct node *new_node = (struct node *)malloc(sizeof(struct node));

    new_node->data = new_data;
    new_node->prev = NULL;
    new_node->next = NULL;

    if (isEmpty()) {
        fronts = new_node;
        rear = new_node;
    } else {
        rear->next = new_node;
        new_node->prev = rear;
        rear = new_node;
    }
}

struct node* search(int key) {
    struct node *temp = fronts;
    while (temp != NULL) {
        if (temp->data == key) {
            return temp;
        }
        temp = temp->next;
    }

    return NULL;
}

void insert_front(int new_data) {
    if (isFull()) {
        printf("Queue overflow. Tidak bisa insert %d.\n", new_data);
        return;
    }

    struct node *new_node = (struct node *)malloc(sizeof(struct node));

    new_node->data = new_data;
    new_node->next = NULL;
    new_node->prev = NULL;

    if (isEmpty()) {
        fronts = new_node;
        rear = new_node;
    } else {
        new_node->next = fronts;
        fronts->prev = new_node->next;
        fronts = new_node;
    }
}

void delete_front() {
    if (isEmpty()) {
        printf("Queue underflow.\n");
        return;
    }

    struct node *temp = fronts;

    fronts = temp->next;

    if (fronts == NULL) {
        rear = NULL;
    } else {
        fronts->prev = NULL;
    }

    free(temp);
}



void delete_rear() {
    if (isEmpty()) {
        printf("Queue underflow.\n");
        return;
    }

    struct node *temp = rear;
    rear = temp->prev;
    if (rear == NULL) {
        fronts = NULL;
    } else {
        rear->next = NULL;
    }
    temp->prev = NULL;

    free(temp);
}

int getfront() {
    return fronts->data;
}

int getrear() {
    return rear->data;
}

void printqueue(struct node *fronts, struct node *rear) {
    struct node *temp = fronts;

    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }

    printf("\n");
}
void insertBetween(int prev_data, int new_data)
{
    // Search for the previous node
    struct node *prev_node = search(prev_data);
    if (prev_node == NULL)
    {
        printf("Data dengan %d tidak ada \n", prev_data);
        return;
    }

    // Create the new node and insert it between the previous and next nodes
    struct node *new_node = (struct node *)malloc(sizeof(struct node));
    new_node->data = new_data;
    new_node->prev = prev_node;
    new_node->next = prev_node->next;

    if (prev_node->next != NULL)
    {
        prev_node->next->prev = new_node;
    }

    prev_node->next = new_node;
}
